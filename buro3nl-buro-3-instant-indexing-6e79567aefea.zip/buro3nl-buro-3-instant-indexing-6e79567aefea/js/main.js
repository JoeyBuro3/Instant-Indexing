$(".upload").on("click", function(){
	var valueToIndex = $(".index-value").val();
	alert(valueToIndex);
});	


/*
$( document ).ready(function() {
	$.ajax({
		url: 'https://indexing.googleapis.com/v3/urlNotifications:publish?key=AIzaSyBzfJFBPcrFAHCLKJc8HeZT8w4hkalVlw0',
		headers: {
			'Authorization' : 'Bearer ya29.a0AVA9y1tx7K1CYMfKWtPAIFd88EoVhV1m6Y44tmkzROqWR23ZhNwMFUrPO-IAGQDKdjJUUKx2KKbS9dQQ7DrVe85_LU8EltrVNJ4Ny3-wYAFRUfFROFoT60c3t1synTyhntfCkYn5r5CY6oyZYCv83GVOTWTEaCgYKATASAQASFQE65dr86NxUixXDXed_RFQ4_tX0Gg0163',
			'Content-Type':'application/json',
			'Accept-Encoding':'gzip, deflate, br',
			'Connection':'keep-alive'
		},
		method: 'POST',	
		dataType: 'json',
		data: {
		  'url': 'https://stupefied-blackburn.45-82-188-188.plesk.page',
		  'type': 'URL_UPDATED'
		},
		success: function(result){
			console.log(result);
		}
	})

});
*/